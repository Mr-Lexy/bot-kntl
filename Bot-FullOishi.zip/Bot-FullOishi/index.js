const qrcode = require("qrcode-terminal");
const moment = require("moment");
const cheerio = require("cheerio");
const get = require('got')
const fs = require("fs");
const dl = require("./lib/downloadImage.js");
const fetch = require('node-fetch');
const urlencode = require("urlencode");
const axios = require("axios");
const imageToBase64 = require('image-to-base64');
const menu = require("./lib/menu.js");
const donate = require("./lib/donate.js");
const info = require("./lib/info.js");
//
const BotName = '<Leri01-BOTZ>'; // Nama Bot Whatsapp
const instagramlu = 'https://www.instagram.com/lord.oishi404_randomofficial/'; // Nama Instagramlu cok
const whatsapplu = '+62 857-4813-8952'; // Nomor whatsapplu cok
const kapanbotaktif = '19 Jam'; // Kapan bot lu aktif
const vthearapi = 'KepoLuKntlAjgAsdasuwuqwe123'
const grupch1 = '-'; // OFFICIAL GRUP LU 1
const grupch2 = '-'; // OFFICIAL GRUP LU 2
//
const
{
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   waChatKey,
   tts,
} = require("@adiwajshing/baileys");
var jam = moment().format("HH:mm");

function foreach(arr, func)
{
   for (var i in arr)
   {
      func(i, arr[i]);
   }
}
const conn = new WAConnection()
conn.on('qr', qr =>
{
   qrcode.generate(qr,
   {
      small: true
   });
   console.log(`[ ${moment().format("HH:mm:ss")} ] Scan kode qr mu cok!`);
});

conn.on('credentials-updated', () =>
{
   // save credentials whenever updated
   console.log(`credentials updated!`)
   const authInfo = conn.base64EncodedAuthInfo() // get all the auth info we need to restore this session
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t')) // save this info to a file
})
fs.existsSync('./session.json') && conn.loadAuthInfo('./session.json')
// uncomment the following line to proxy the connection; some random proxy I got off of: https://proxyscrape.com/free-proxy-list
//conn.connectOptions.agent = ProxyAgent ('http://1.0.180.120:8080')
conn.connect();

conn.on('user-presence-update', json => console.log(`[ ${moment().format("HH:mm:ss")} ] => bot by Leri01`))
conn.on('message-status-update', json =>
{
   const participant = json.participant ? ' (' + json.participant + ')' : '' // participant exists when the message is from a group
   console.log(`[ ${moment().format("HH:mm:ss")} ] => bot by Leri01`)
})

conn.on('message-new', async(m) =>
{
   const messageContent = m.message
   const text = m.message.conversation
   let id = m.key.remoteJid
   const messageType = Object.keys(messageContent)[0] // message will always contain one key signifying what kind of message
   let imageMessage = m.message.imageMessage;
   console.log(`[ ${moment().format("HH:mm:ss")} ] => Nomor: [ ${id.split("@s.whatsapp.net")[0]} ] => ${text}`);


// Groups

        
if (text.includes("#buatgrup"))
   {
var nama = text.split("#buatgrup")[1].split("-nomor")[0];
var nom = text.split("-nomor")[1];
var numArray = nom.split(",");
for ( var i = 0; i < numArray.length; i++ ) {
    numArray[i] = numArray[i] +"@s.whatsapp.net";
}
var str = numArray.join("");
console.log(str)
const group = await conn.groupCreate (nama, str)
console.log ("created group with id: " + group.gid)
conn.sendMessage(group.gid, "Hello Gays Leri01 Bot Disini :v", MessageType.extendedText) // say hello to everyone on the group

}

// FF
if(text.includes("#cek")){
var num = text.replace(/#cek/ , "")
var idn = num.replace("0","+62");

console.log(id);
const gg = idn+'@s.whatsapp.net'

const exists = await conn.isOnWhatsApp (gg)
console.log(exists);
conn.sendMessage(id ,`${gg} ${exists ? " exists " : " does not exist"} on Bumi`, MessageType.text)
}

/*if (text.includes("#tts")){
const teks = text.replace(/#tts /, "")
const gtts = (`https://rest.farzain.com/api/tts.php?id=${teks}&apikey=O8mUD3YrHIy9KM1fMRjamw8eg`)
    conn.sendMessage(id, gtts ,MessageType.text);
}*/

if (text.includes('#nulis')){
  var teks = text.replace(/#nulis /, '')
    axios.get('https://bangandre.herokuapp.com/nulis?teks='+teks)
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] Membuat Tulisan... ', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes("#ytmp3")){
const teks = text.replace(/#ytmp3 /, "")
axios.get(`https://api.vhtear.com//ytmp3?query=${teks}&apikey=${vthearapi}`).then((res) => {
	conn.sendMessage(id, '[❗] Membuat Link Download... ', MessageType.text)
    let hasil = `*Judul:* ${res.data.result.title}\n\n *Size:* ${res.data.result.size}\n\n *Audio:* ${res.data.result.mp3}\n\n *Duration:* ${res.data.result.duration}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#masak")){
const teks = text.replace(/#masak /, "")
axios.get(`https://api.vhtear.com/resepmasakan?query=${teks}&apikey=${vthearapi}`).then((res) => {
    let hasil = `CARA MEMASAK *${res.data.result.title}*\n\nBahan Bahan: *${res.data.result.bahan}*\n\nCara Memasak : *${res.data.result.cara}*\n`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}


if (text.includes("#yutubdl")){
const teks = text.replace(/#yutubdl /, "")
axios.get(`https://scrap.terhambar.com/yt?link=${teks}`).then((res) => {
    let hasil = `Terjadi Kesalahan Server Saat MengUpload.Kamu Dapat Mengunduh Secara Manual Disini :..\n\nJudul Video: ${res.data.title}\n\nLink: ${res.data.linkVideo}\n\nDurasi : ${res.data.inText}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#fb")){
const teks = text.replace(/#fb /, "")
axios.get(`https://api.vhtear.com/fbdl?link=${teks}&apikey=${vthearapi}`).then((res) => {
    let hasil = `BERHASIL DI *DOWNLOAD!* SILAHKAN UNDUH MELALUI LINK BERIKUT\n\nJudul: - \n\nLink: ${res.data.result.VideoUrl}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#buatnama")){
const teks = text.replace(/#buatnama /, "")
axios.get(`https://api.terhambar.com/nama?jenis=${teks}`).then((res) => {
    let hasil = `NAMA YANG COCOK UNTUK ANAKMU/MU\n\n*${res.data.result.nama}*`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#stalkig")){
  const teks = text.replace(/#stalkig /, "")
  axios.get(`https://alfians-api.herokuapp.com/api/stalk?username=${teks}`).then ((res) =>{
  conn.sendMessage(id, '[❗] Sabar Lagi Stalking IG Punya '+teks, MessageType.text)
  let hasil = `YAHAHA TELAH DI STALK BOS KU UNTUK USERNAME ${teks} \n\n *Username👀* : _${res.data.Username}_ \n *Nama✍️* : _${res.data.Name}_ \n *Jumlah Follower🤷‍♀️¸* : _${res.data.Jumlah_Followers}_ \n *Jumlah Following👥¸* : _${res.data.Jumlah_Following}_ \n *Jumlah Post💌* : _${res.data.Jumlah_Post}_ `;
  conn.sendMessage(id, hasil, MessageType.text);
})
}

if (text.includes("#lirik")){
const teks = text.replace(/#lirik /, "")
axios.get(`https://scrap.terhambar.com/lirik?word=${teks}`).then((res) => {
    let hasil = `${res.data.result.lirik}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}


if (text.includes("#brain")){
const teks = text.replace(/#brain /, "")
axios.get(`https://api.vhtear.com/branly?query=${teks}&apikey=${vthearapi}`).then((res) => {
    let hasil = `${res.data.result.data}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#jadwalsholat")){
const teks = text.replace(/#jadwalsholat /, "")
axios.get(`https://tobz-api.herokuapp.com/api/jadwalshalat?q=${teks}`).then((res) => {
    let hasil = `JADWAL SHOLAT DI ${teks}\n\nSubuh: ${res.data.result.subuh}\nDzuhur: ${res.data.result.dzuhur}\nAshar: ${res.data.result.ashar}\nMaghrib: ${res.data.result.maghrib}\nIsya : ${res.data.result.isha}\nTengah Malem: ${res.data.result.midnight}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("#quotes")){
const teks = text.replace(/#quotes /, "")
axios.get(`https://alfians-api.herokuapp.com/api/randomquotes`).then((res) => {
    let hasil = `*_${res.data.quotes}_*\n\n\n  _${res.data.author}_`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("#convert")){
const teks = text.replace(/#convert /, "")
axios.get(`https://api.terhambar.com/currency?curr=usd&bal=${teks}`).then((res) => {
    let hasil = `HASIL DARI $${teks} Adalah\n\n*${res.data.result.resultConvert}*`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}


if (text.includes("#chord")){
const teks = text.replace(/#chord /, "")
axios.get(`https://st4rz.herokuapp.com/api/chord?q=${teks}`).then((res) => {
    let hasil = `${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#ceknope")){
const teks = text.replace(/#ceknope /, "")
axios.get(`https://api.vhtear.com/nomerhoki?no=${teks}&apikey=${vthearapi}`).then((res) => {
    let hasil = `${res.data.result.hasil}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#simi")){
const teks = text.replace(/#simi /, "")
axios.get(`https://st4rz.herokuapp.com/api/simsimi?kata=${teks}`).then((res) => {
    let hasil = `*${res.data.result}*`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}



if (text.includes("#ig")){
const teks = text.replace(/#ig /, "")
axios.get(`https://api.vhtear.com/instadl?link=${teks}&apikey=${vthearapi}`).then((res) => {
    let hasil = `YOI UDH JADI LINK NYA:3\n\nOWNER POST: ${res.data.result.post.owner_username}\n\nLINK DOWNLOAD : ${res.data.result.post.urlDownload}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#shortit")){
const teks = text.replace(/#shortit /, "")
axios.get(`https://api.vhtear.com/shortener?link=${teks}&apikey=${vthearapi}`).then((res) => {
	conn.sendMessage(id, '[❗] Memendekan URL... ', MessageType.text)
    let hasil = `nih kak :) \n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#ttslontong")){
const teks = text.replace(/#ttslontong /, "")
axios.get(`https://api.vhtear.com/funkuis&apikey=${vthearapi}`).then((res) => {
	conn.sendMessage(id, '[❗] SOAL : '+res.data.result.soal, MessageType.text)
    let hasil = `YHAAA GA TAU YA?? \n\nJawaban: ${res.data.result.jawaban}\nKarena : ${res.data.result.desk}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}


if (text.includes("#zodiak")){
const teks = text.replace(/#zodiak /, "")
axios.get(`https://api.vhtear.com/zodiak?query=${teks}&apikey=${vthearapi}`).then((res) => {
	conn.sendMessage(id, '[✔️] ZODIAK '+ teks + ' DITEMUKAN!', MessageType.text)
    let hasil = `ZODIAK: *${res.data.result.zodiak}*\n\nRAMALAN : *${res.data.result.ramalan}*\n\nLUCKY NUMBER : ${res.data.result.nomorKeberuntungan}\n\nMOTIVASI: ${res.data.result.motivasi}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}


if (text.includes("#bapack")){
const teks = text.replace(/#bapack /, "")
axios.get(`https://api.terhambar.com/bpk?kata=${teks}`).then((res) => {
    let hasil = `*${teks}* ==> *${res.data.text}*`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}


if (text.includes("#spamcall")){
const teks = text.replace(/#spamcall /, "")
axios.get(`https://alfians-api.herokuapp.com/api/spamcall?no=${teks}`).then((res) => {
    let hasil = `*${res.data.logs}*\n\nNote : LIMIT 5 SPAM PerDay!`;
    conn.sendMessage(id, hasil,MessageType.text);
})
}

if (text.includes("#scrapanime")){
const teks = text.replace(/#scrapanime /, "")
axios.get(`https://alfians-api.herokuapp.com/api/kuso?q=${teks}`).then((res) => {
    let hasil = `HASIL DIBAWAH :\n\n*ANIME ${res.data.title} TELAH DI SCRAPT!!*\n\n*Judul Anime* : ${res.data.title}\n\n*Informasi*: ${res.data.info}\n\n*Sinopsis* : ${res.data.sinopsis}\n\n*LinkDownload* : ${res.data.link_dl}\n\n*Image* :${res.data.thumb}`;
    conn.sendMessage(id, hasil,MessageType.text);
})
}

if (text.includes('#randomhentong')){
  var teks = text.replace(/#randomhentong /, '')
    axios.get('https://tobz-api.herokuapp.com/api/hentai')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] Bacol Hentai Sedang Dikirimkan.. ', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes('#detailhero')){
  var teks = text.replace(/#detailhero /, '')
    axios.get('https://api.vhtear.com/herodetail?query='+ teks +'&apikey='+vthearapi)
    .then((res) => {
      imageToBase64(res.data.result.pictHero)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] Hero: '+res.data.result.title+'\n[❓] Quotes: '+res.data.result.quotes+'\n[⚠️]Information: '+res.data.result.info+'\nAttributes: '+res.data.result.attributes, MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes('#makecalender')){
  var teks = text.replace(/#makecalender /, '')
    axios.get('https://api.vhtear.com/calender?link='+ teks +'&apikey='+vthearapi)
    .then((res) => {
      imageToBase64(res.data.result.imgUrl)
        .then(
          (ress) => {
            conn.sendMessage(id, '[✍️] Wait Sedang Membuat Calender... ', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes('#jooxdl')){
  var teks = text.replace(/#jooxdl /, '')
    axios.get('https://tobz-api.herokuapp.com/api/joox?q='+teks)
    .then((res) => {
      imageToBase64(res.data.result.thumb)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] LAGU YANG DICARI BERHASIL DITEMUKAN!!\n\n[❓] Judul Lagu: '+res.data.result.album+'\n[🤔] Vocal: '+res.data.result.judul+'\n[✍️] Tanggal Rilis: '+res.data.result.dipublikasi+'\n[📖] Link Download : '+res.data.result.mp3, MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes('#nsfwtrap')){
  var teks = text.replace(/#nsfwtrap /, '')
    axios.get('https://tobz-api.herokuapp.com/api/nsfwtrap')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗NSFW {TRAP} Sedang Dikirimkan.. ', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes('#nsfwnekonime')){
  var teks = text.replace(/#nsfwnekonime /, '')
    axios.get('https://tobz-api.herokuapp.com/api/nsfwneko')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] NEKONIME {NSFW} Sedang Dikirimkan.. ', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes('#bikinquote')){
  const request = require('request');
    var gh = text.split("#bikinquote ")[1];
    var kata1 = gh.split("&")[0];
    var author = gh.split("&")[1];
    axios.get('https://terhambar.com/aw/qts/?kata='+ kata1 +'&author='+ author +'&tipe=random')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[(^o^)] Membuat Quotes...', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes('#artijodoh')){
  const request = require('request');
    var gh = text.split("#artijodoh ")[1];
    var namalu = gh.split("&")[0];
    var pasangan = gh.split("&")[1];
    axios.get('https://api.vhtear.com/primbonjodoh?nama='+ namalu +'&pasangan='+ pasangan +'&apikey='+vthearapi)
          .then((res) => {
            conn.sendMessage(id, '[(^o^)] MENCARI HASIL...', MessageType.text)
            let hasil = `${res.data.result.hasil}`;
            conn.sendMessage(id, hasil, MessageType.text)
        })
}




if (text.includes('#randomloli')){
  var teks = text.replace(/#randomloli /, '')
    axios.get('https://alfians-api.herokuapp.com/api/randomloli')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[🌠] Sedang Ngirim Gambar Loli Kamu>//<', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes('#tebakin')){
  var teks = text.replace(/#tebakin /, '')
    axios.get('https://api.vhtear.com/tebakgambar&apikey='+vthearapi)
    .then((res) => {
      imageToBase64(res.data.result.soalImg)
        .then(
          (ress) => {
            conn.sendMessage(id, '[🌠] Sedang Ngirim Gambar Soal', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}


if (text.includes('#bikinteks')){
  var teks = text.replace(/#bikinteks /, '')
    axios.get('https://st4rz.herokuapp.com/api/ttp?kata='+teks)
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[🌟] Sedang Ngirim Text Gambar...', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
    
} 



if (text.includes("#spamsms")){
const teks = text.replace(/#spamsms /, "")
axios.get(`https://alfians-api.herokuapp.com/api/spamsms?no=${teks}&jum=5`).then((res) => {
    let hasil = `HASIL :\n${res.data.logs}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#wiki")){
const teks = text.replace(/#wiki /, "")
axios.get(`https://st4rz.herokuapp.com/api/wiki?q=${teks}`).then((res) => {
    let hasil = `Menurut Wikipedia:\n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#hitung")){
const teks = text.replace(/#hitung /, "")
axios.get(`https://api.vhtear.com//calculator?value=${teks}&apikey=${vthearapi}`).then((res) => {
    let hasil = `HASIL:\n\n${res.data.result.data}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#jadwaltv")){
const teks = text.replace(/#jadwaltv /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/jdtv?ch=${teks}&apiKey=YL002PRoRhX9w7xssJex`).then((res) => {
    let hasil = `JADWAL CHANNEL *${teks}* HARI INI ADALAH:\n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}


if (text.includes("#infogempa")){
const teks = text.replace(/#infogempa /, "")
axios.get(`https://st4rz.herokuapp.com/api/infogempa`).then((res) => {
    let hasil = `BERIKUT INFO GEMPA TERBARU:\n\n${res.data.kedalaman}\n\nKoordinat: ${res.data.koordinat}\n\nLokasi : ${res.data.lokasi}\n\nInfo Map : ${res.data.map}\n\nPotensi : ${res.data.potensi}\n\nWaktu Kejadian : ${res.data.waktu}\n\n\n`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#kbbi")){
const teks = text.replace(/#kbbi /, "")
axios.get(`https://tobz-api.herokuapp.com/api/kbbi?kata=${teks}`).then((res) => {
    let hasil = `Menurut KBBI Arti Dari *${teks}* Adalah :\n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes("#cekfilm")){
const teks = text.replace(/#cekfilm /, "")
axios.get(`https://rest.farzain.com/api/film.php?id=${teks}&apikey=uXFtM15mpXFxZmLAJkiBqcUXD`).then((res) => {
    let hasil = `HASIL PENCARIAN FILM *${teks}* Ditemukan!\n\nJumdul Film : ${res.data.Title}\n\nTahun Rilis : ${res.data.Released}\n\nRating Film : ${res.data.Rated}\n\nGenre : ${res.data.Genre}\n\nDurasi : ${res.data.Runtime}\n\nWritter / Sutradara: ${res.data.Writer} / ${res.data.Director}\n\n Sinopsis : ${res.data.Plot}\n\n Negara Pembuat : ${res.data.Country}\n\n Penghasilan : ${res.data.BoxOffice}\n\nWebsite Resmi : ${res.data.Website}` ;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text == '#openmenu'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, menu.menu(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#quran'){
axios.get('https://api.banghasan.com/quran/format/json/acak').then((res) => {
    const sr = /{(.*?)}/gi;
    const hs = res.data.acak.id.ayat;
    const ket = `${hs}`.replace(sr, '');
    let hasil = `[${ket}]   ${res.data.acak.ar.teks}\n\n${res.data.acak.id.teks}(QS.${res.data.surat.nama}, Ayat ${ket})`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
else if (text == 'assalamualaikum'){
conn.sendMessage(id, 'Waalaikumsalam, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'salam'){
conn.sendMessage(id, 'Waalaikumsalam, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'asalamualaikum'){
conn.sendMessage(id, 'Waalaikumsalam, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == '#kickme'){
conn.sendMessage(id, '*Berhasil!* Kamu Telah Dihapus Dari Daftar Penerima Pesan Siaran! ' ,MessageType.text);
}
else if (text == 'Assalamualaikum'){
conn.sendMessage(id, 'Waalaikumsalam, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'p'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'P'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == '#menu'){
conn.sendMessage(id, 'Command Bot Sekarang Menjadi #openmenu!.' ,MessageType.text);
}
else if (text.includes == '#say'){
conn.sendMessage(id, 'FITUR #say UDAH DIHAPUS NGEMTOD, W KENA FITNAH MULU AJG APALAGI SAMA SI YANTO, GA SENANG PM!' ,MessageType.text);
}
else if (text == '#help'){
conn.sendMessage(id, 'Command Bot Sekarang Menjadi #openmenu!..' ,MessageType.text);
}
else if (text == 'halo'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'hai'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'woi'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'woy'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'hi'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'gan'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'sis'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'bro'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'min'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'sayang'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'i love u'){
conn.sendMessage(id, 'love you too' ,MessageType.text);
}
else if (text == 'mas'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'mba'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == '#puas'){
conn.sendMessage(id, 'Terima Kasih,Kalau Anda Suka Share Bot Ini. Iklan Bot Dimulai 1 Menit' ,MessageType.text);
}
else if (text == '#tidakpuas'){
conn.sendMessage(id, 'Maaf, Kami Akan Tingkatkan Lagi.\NSupaya Bot Berkembang Dengan Baik, Anda Bisa Ikut BERDONASI Dengan Ketik #donasi..' ,MessageType.text);
}
else if (text == 'bre'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'Oi'){
conn.sendMessage(id, 'Apaan? Ini Nomor Bot Masukan #openmenu Untuk Mengetahui List Menu' ,MessageType.text);
}
else if (text == 'cuy'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'euy'){
conn.sendMessage(id, 'Ya?, ada yang bisa saya bantu? kalo bingung ketik #openmenu ya say..' ,MessageType.text);
}
else if (text == 'makasi'){
conn.sendMessage(id, 'Sama sama, semoga harimu menyenangkan :)' ,MessageType.text);
}
else if (text == 'Makasi'){
conn.sendMessage(id, 'Sama sama, semoga harimu menyenangkan :)' ,MessageType.text);
}
else if (text == 'makasih'){
conn.sendMessage(id, 'Sama sama, semoga harimu menyenangkan :)' ,MessageType.text);
}
else if (text == 'Makasih'){
conn.sendMessage(id, 'Sama sama, semoga harimu menyenangkan :)' ,MessageType.text);
}
else if (text == 'thank'){
conn.sendMessage(id, 'Sama sama, semoga harimu menyenangkan :)' ,MessageType.text);
}
else if (text == 'Thank'){
conn.sendMessage(id, 'Sama sama, semoga harimu menyenangkan :)' ,MessageType.text);
}
else if (text == 'thanks'){
conn.sendMessage(id, 'Sama sama, semoga harimu menyenangkan :)' ,MessageType.text);
}
else if (text == '#stiker'){
conn.sendMessage(id, 'bukan #stiker,tetapi #sticker' ,MessageType.text);
}
else if (text == 'Thanks'){
conn.sendMessage(id, 'Sama sama, semoga harimu menyenangkan :)' ,MessageType.text);
}
else if (text == '#donate'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#donasi'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#DONATE'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#DONASI'){
  const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#info'){
  const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, info.info(id, BotName, corohelp, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) ,MessageType.text);
}
else if (text == '#gacha'){
conn.sendMessage(id, 'kirim #gacha cewek/cowok\n\nContoh: #gacha cewek' ,MessageType.text);
}
   if (messageType == 'imageMessage')
   {
      let caption = imageMessage.caption.toLocaleLowerCase()
      const buffer = await conn.downloadMediaMessage(m) // to decrypt & use as a buffer
      if (caption == '#sticker')
      {
         const stiker = await conn.downloadAndSaveMediaMessage(m) // to decrypt & save to file

         const
         {
            exec
         } = require("child_process");
         exec('cwebp -q 50 ' + stiker + ' -o temp/' + jam + '.webp', (error, stdout, stderr) =>
         {
            let stik = fs.readFileSync('temp/' + jam + '.webp')
            conn.sendMessage(id, stik, MessageType.sticker)
         });
      }
   }
   
 
   
   if (messageType === MessageType.text)
   {
      let is = m.message.conversation.toLocaleLowerCase()

      if (is == '#pantun')
      {

         fetch('https://raw.githubusercontent.com/pajaar/grabbed-results/master/pajaar-2020-pantun-pakboy.txt')
            .then(res => res.text())
            .then(body =>
            {
               let tod = body.split("\n");
               let pjr = tod[Math.floor(Math.random() * tod.length)];
               let pantun = pjr.replace(/pjrx-line/g, "\n");
               conn.sendMessage(id, pantun, MessageType.text)
            });
      }

   }
  
     if (messageType === MessageType.text)
   {
      let is = m.message.conversation.toLocaleLowerCase()

      if (is == '#cekbapak')
      {

         fetch('https://raw.githubusercontent.com/WhatTheSemvak/bot-wasapp/main/randombapak.txt')
            .then(res => res.text())
            .then(body =>
            {
               let tod = body.split("\n");
               let pjr = tod[Math.floor(Math.random() * tod.length)];
               let cekbapak = pjr.replace(/pjrx-line/g, "\n");
               conn.sendMessage(id, cekbapak, MessageType.text)
            });
      }

   }
   
  /*if (text.includes("#yt"))
   {
      const url = text.replace(/#yt/, "");
      const exec = require('child_process').exec;

      var videoid = url.match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/);

      const ytdl = require("ytdl-core")
      if (videoid != null)
      {
         console.log("video id = ", videoid[1]);
      }
      else
      {
         conn.sendMessage(id, "gavalid", MessageType.text)
      }
      ytdl.getInfo(videoid[1]).then(info =>
      {
         if (info.length_seconds > 1000)
         {
            conn.sendMessage(id, " videonya kepanjangan", MessageType.text)
         }
         else
         {

            console.log(info.length_seconds)

            function os_func()
            {
               this.execCommand = function (cmd)
               {
                  return new Promise((resolve, reject) =>
                  {
                     exec(cmd, (error, stdout, stderr) =>
                     {
                        if (error)
                        {
                           reject(error);
                           return;
                        }
                        resolve(stdout)
                     });
                  })
               }
            }
            var os = new os_func();

            os.execCommand('ytdl ' + url + ' -q highest -o mp4/' + videoid[1] + '.mp4').then(res =>
            {
		const buffer = fs.readFileSync("mp4/"+ videoid[1] +".mp4")
               conn.sendMessage(id, buffer, MessageType.video)
            }).catch(err =>
            {
               console.log("os >>>", err);
            })

         }
      });

   }*/


   if (text.includes("#nulis"))
   {

      const
      {
         spawn
      } = require("child_process");
      console.log("writing...")
      const teks = text.replace(/#nulis/, "")
      const split = teks.replace(/(\S+\s*){1,10}/g, "$&\n")
      const fixedHeight = split.split("\n").slice(0, 25).join("\\n")
      console.log(split)
      spawn("convert", [
            "./assets/paper.jpg",
            "-font",
            "Indie-Flower",
            "-size",
            "700x960",
            "-pointsize",
            "16",
            "-interline-spacing",
            "3",
            "-annotate",
            "+170+222",
            fixedHeight,
            "./assets/result.jpg"
         ])
         .on("error", () => console.log("error"))
         .on("exit", () =>
         {
            const buffer = fs.readFileSync("assets/result.jpg") // can send mp3, mp4, & ogg -- but for mp3 files the mimetype must be set to ogg

            conn.sendMessage(id, buffer, MessageType.image)
            console.log("done")
         })
   }


   

   if (text.includes("#gacha cewek"))
   {
    var items = ["ullzang girl", "cewe cantik", "hijab cantik", "korean girl", "cewe sexy"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }



    
   if (text.includes("#gacha cowok"))
   {
    var items = ["cowo ganteng", "cogan", "korean boy", "chinese boy", "japan boy"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
  var buf = Buffer.from(response, 'base64'); // Ta-da 
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }

if (text.includes("#randomanime"))
   {
    var items = ["anime sange", "anime cantik", "zero two", "sexy sagiri", "sexy waifu"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
    
    
    if (text.includes("#randommoba"))
   {
    var items = ["sexy hero mobile legends", "mobile legends nude heroes", "sex mobile legends", "sexy hero mobile legends", "mobile legends sexy"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }

/*if (text.includes("#scdl")){
const fs = require("fs");
const scdl = require("./lib/scdl");

scdl.setClientID("iZIs9mchVcX5lhVRyQGGAYlNPVldzAoX");

scdl("https://m.soundcloud.com/abdul-muttaqin-701361735/lucid-dreams-gustixa-ft-vict-molina")
    .pipe(fs.createWriteStream("mp3/song.mp3"));
}



 else if (text.includes("#tts")) {
  var teks = text.split("#ttsid ")[1];
  var path = require('path');
  var url = ('http://api.farzain.com/tts.php?id=${text}&apikey=uXFtM15mpXFxZmLAJkiBqcUXD');
  var text1 = teks.slice(6);
  text1 = suara;
  var suara = text.replace(/#ttsid/g, text1);
  var filepath = 'mp3/bacot.wav';
  
  
/*
 * save audio file
 */
/*
tts.save(filepath, suara, function() {
  console.log(`${filepath} MP3 SAVED!`)
});
await new Promise(resolve => setTimeout(resolve, 500));

	if(suara.length > 200){ // check longness of text, because otherways google translate will give me a empty file
  msg.reply("Text kepanjangan bro!")
}else{

const buffer = fs.readFileSync(filepath)
	conn.sendMessage(id , buffer , MessageType.audio);

};


}*/






   // end of file


})
